"""mofscreen — MOF DFT Screening Library (v1.0.0)"""
import importlib.util, sys, os as _os
_d = _os.path.dirname(__file__)
for _n in ["_core", "cli"]:
    _s = importlib.util.spec_from_file_location(
        f"mofscreen.{_n}", _os.path.join(_d, f"{_n}.pyc"))
    _m = importlib.util.module_from_spec(_s)
    sys.modules[f"mofscreen.{_n}"] = _m
    _s.loader.exec_module(_m)
from mofscreen._core import (AllResults, BandgapResult, AdsorptionResult,
                               FormationResult, VolumeResult, run_screening)
from mofscreen._core import read
__version__ = "1.0.0"

class MOFScreener:
    """MOF DFT Screener — see help(MOFScreener) for full docs."""
    def __init__(self, cif_path, cores=16, mpi_ranks=1, cp2k_data_dir=None,
                 high_accuracy=False, fast_mode=False, li_ref_ev=None):
        import os, logging
        from pathlib import Path
        from mofscreen._core import load_reference_energies
        self.cif_path=_os.path.abspath(cif_path); self.cores=cores
        self.mpi_ranks=mpi_ranks; self.cp2k_data_dir=cp2k_data_dir
        self.high_accuracy=high_accuracy; self.fast_mode=fast_mode
        self.li_ref_ev=li_ref_ev
        if cp2k_data_dir: _os.environ["CP2K_DATA_DIR"]=cp2k_data_dir
        if not _os.path.exists(self.cif_path):
            raise FileNotFoundError(f"CIF not found: {self.cif_path}")
        self._atoms=read(self.cif_path)
        self._out_dir=Path(_os.path.dirname(self.cif_path))/"results"
        self._out_dir.mkdir(exist_ok=True)
        ref_file=self._out_dir/"elemental_refs"/"ref_energies.json"
        self._refs=load_reference_energies(ref_file)
        self._bandgap_result=None; self._ads_result=None
        log=logging.getLogger("mof_dft")
        log_path=self._out_dir/"run.log"
        if not any(isinstance(h,logging.FileHandler) for h in log.handlers):
            fh=logging.FileHandler(str(log_path))
            fh.setFormatter(logging.Formatter("%(asctime)s  %(levelname)-7s  %(message)s",datefmt="%H:%M:%S"))
            log.addHandler(fh)

    def calc_bandgap(self, multiplicity=None):
        from mofscreen._core import calc_bandgap as _f
        self._bandgap_result=_f(self._atoms,self._out_dir,self.cores,self.mpi_ranks,self.high_accuracy,self.fast_mode,multiplicity)
        return self._bandgap_result

    def calc_adsorption(self, n_li=1, cell_opt=False, multiplicity=None):
        from mofscreen._core import calc_adsorption_energy as _f
        if self._bandgap_result is None: self.calc_bandgap(multiplicity)
        li_ref=self._refs.get("Li", self.li_ref_ev or -1.900)
        self._ads_result=_f(self._atoms,self._bandgap_result.total_energy_ev,self._out_dir,self.cores,self.mpi_ranks,self.high_accuracy,self.fast_mode,n_li,cell_opt,li_ref,multiplicity)
        return self._ads_result

    def calc_formation(self, ref_energies_file=None):
        from mofscreen._core import calc_formation_energy as _f, load_reference_energies
        from pathlib import Path
        if self._bandgap_result is None: self.calc_bandgap()
        if ref_energies_file: self._refs=load_reference_energies(Path(ref_energies_file))
        return _f(self._atoms,self._bandgap_result.total_energy_ev,self._refs)

    def calc_volume(self, cell_opt=False):
        from mofscreen._core import calc_volume_expansion as _f
        if self._ads_result is None: self.calc_adsorption(cell_opt=cell_opt)
        return _f(self._atoms,self._out_dir,cell_opt)

    def compute_references(self):
        from mofscreen._core import compute_all_references
        elements=set(self._atoms.get_chemical_symbols())|{"Li"}
        self._refs=compute_all_references(elements,self._out_dir,self.cores,self.mpi_ranks,self.high_accuracy,self.fast_mode)
        return self._refs

    def run_all(self, n_li=1, cell_opt=False, compute_refs=False, multiplicity=None, ref_energies_file=None):
        return run_screening(cif_path=self.cif_path,num_cores=self.cores,mpi_ranks=self.mpi_ranks,use_high_accuracy=self.high_accuracy,fast_mode=self.fast_mode,n_li_ions=n_li,cell_opt=cell_opt,user_mult=multiplicity,ref_energies_file=ref_energies_file,compute_refs=compute_refs,li_ref_ev=self.li_ref_ev,cp2k_data_dir=self.cp2k_data_dir)

    def __repr__(self):
        return f"MOFScreener(cif='{_os.path.basename(self.cif_path)}', cores={self.cores})"

__all__=["MOFScreener","AllResults","BandgapResult","AdsorptionResult","FormationResult","VolumeResult"]
