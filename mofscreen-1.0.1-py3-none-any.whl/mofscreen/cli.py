from mofscreen._core import *
import sys, os

def main():
    import importlib.util
    _d = os.path.dirname(__file__)
    _s = importlib.util.spec_from_file_location("mofscreen.cli_impl", os.path.join(_d, "cli.pyc"))
    _m = importlib.util.module_from_spec(_s)
    _s.loader.exec_module(_m)
    _m.main()

if __name__ == "__main__":
    main()
